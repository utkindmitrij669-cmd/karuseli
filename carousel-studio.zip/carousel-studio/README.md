# 🎨 Carousel Studio

Генератор Instagram каруселей с AI для экспертов.

## Возможности

- 🤖 **AI-генерация** — создание каруселей через OpenAI GPT-4o-mini
- 🎤 **Голосовой ввод** — диктуйте тему голосом (Web Speech API)
- 📸 **Фото-фоны** — загрузка своих фото или генерация через DALL-E 3
- 🎨 **6 тем** — минимализм, тёмная, океан, закат, природа, неон
- 🖋 **4 шрифта** — Outfit, Playfair Display, Space Grotesk, Sora
- 📐 **2 формата** — 1080×1080 (квадрат) и 1080×1350 (вертикальный)
- 🖼 **2 режима фото** — затемнение с наложением и сплит-лейаут
- ↓ **Экспорт PNG** — скачивание отдельных слайдов или всех сразу

## Запуск

```bash
npm install
npm run dev
```

## Деплой на Vercel

1. Push в GitHub
2. Подключить репо в [vercel.com](https://vercel.com)
3. Framework preset: **Vite**
4. Deploy!

## Технологии

- React 18
- Vite 6
- OpenAI API (GPT-4o-mini + DALL-E 3)
- Web Speech API
- Canvas API для экспорта PNG
